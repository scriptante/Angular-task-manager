import { Component, inject } from '@angular/core';
import { ModalController } from '../../services/modal-controller';

@Component({
  selector: 'app-welcome-section',
  imports: [],
  templateUrl: './welcome-section.html',
  styleUrl: './welcome-section.css',
})
export class WelcomeSection {
  private readonly modalNewTask = inject(ModalController)

  createNewTask() {
    this.modalNewTask.openNewTaskModal();
  }
}
