import { Component, inject } from '@angular/core';
import { ModalController } from '../../services/modal-controller';

@Component({
  selector: 'app-task-card',
  imports: [],
  templateUrl: './task-card.html',
  styleUrl: './task-card.css',
})
export class TaskCard {
  private readonly modalController = inject(ModalController)

  editTask() {
    this.modalController.openEditTaskModal({ name: 'Nova tarefa', description: 'Descrição tarefa' });
  }
}
